package com.monir.youtubelivestreamer.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import com.monir.youtubelivestreamer.R
import com.monir.youtubelivestreamer.databinding.ActivityMainBinding
import com.monir.youtubelivestreamer.model.PlaylistItem
import com.monir.youtubelivestreamer.model.StreamQuality
import com.monir.youtubelivestreamer.model.StreamState
import com.monir.youtubelivestreamer.model.StreamStatus
import com.monir.youtubelivestreamer.security.SecureStreamPreferences
import com.monir.youtubelivestreamer.service.StreamService
import kotlinx.coroutines.launch
import java.util.UUID

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var preferences: SecureStreamPreferences
    private lateinit var playlistAdapter: PlaylistAdapter
    private val playlist = mutableListOf<PlaylistItem>()

    private val videoPickerLauncher = registerForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris: List<Uri>? ->
        if (!uris.isNullOrEmpty()) {
            handleSelectedVideos(uris)
        }
    }

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            proceedStartStream()
        } else {
            Toast.makeText(
                this,
                "Notification permission is needed for background streaming status.",
                Toast.LENGTH_LONG
            ).show()
            proceedStartStream()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        preferences = SecureStreamPreferences(this)
        setupUI()
        loadSavedPreferences()
        observeStreamStatus()
    }

    private fun setupUI() {
        playlistAdapter = PlaylistAdapter { itemToRemove ->
            removeItemFromPlaylist(itemToRemove)
        }
        binding.rvPlaylist.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = playlistAdapter
        }

        binding.btnSelectVideos.setOnClickListener {
            videoPickerLauncher.launch(arrayOf("video/mp4", "video/*"))
        }

        binding.rgQuality.setOnCheckedChangeListener { _, checkedId ->
            val quality = if (checkedId == R.id.rb1080p) StreamQuality.P1080 else StreamQuality.P720
            preferences.saveQuality(quality)
        }

        binding.switchLoopPlaylist.setOnCheckedChangeListener { _, isChecked ->
            preferences.saveLoopPlaylist(isChecked)
        }

        binding.btnStartLive.setOnClickListener {
            requestStartStream()
        }

        binding.btnStopLive.setOnClickListener {
            stopStream()
        }
    }

    private fun loadSavedPreferences() {
        binding.etStreamUrl.setText(preferences.getServerUrl())
        binding.etStreamKey.setText(preferences.getStreamKey())
        binding.switchLoopPlaylist.isChecked = preferences.isLoopPlaylist()

        val savedQuality = preferences.getQuality()
        if (savedQuality == StreamQuality.P1080) {
            binding.rb1080p.isChecked = true
        } else {
            binding.rb720p.isChecked = true
        }

        updatePlaylistUI()
    }

    private fun handleSelectedVideos(uris: List<Uri>) {
        for (uri in uris) {
            try {
                contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (e: Exception) {
            }

            var displayName = "video_${playlist.size + 1}.mp4"
            var fileSize = 0L

            contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (cursor.moveToFirst()) {
                    if (nameIndex != -1) displayName = cursor.getString(nameIndex) ?: displayName
                    if (sizeIndex != -1) fileSize = cursor.getLong(sizeIndex)
                }
            }

            var durationMs = 0L
            try {
                val retriever = MediaMetadataRetriever()
                retriever.setDataSource(this, uri)
                val durationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                durationMs = durationStr?.toLongOrNull() ?: 0L
                retriever.release()
            } catch (e: Exception) {
            }

            val item = PlaylistItem(
                id = UUID.randomUUID().toString(),
                uri = uri,
                title = displayName,
                sizeBytes = fileSize,
                durationMs = durationMs
            )
            playlist.add(item)
        }

        updatePlaylistUI()
    }

    private fun removeItemFromPlaylist(item: PlaylistItem) {
        playlist.removeAll { it.id == item.id }
        updatePlaylistUI()
    }

    private fun updatePlaylistUI() {
        playlistAdapter.submitList(playlist.toList())
        val count = playlist.size
        binding.tvVideoCount.text = if (count == 1) "1 video" else "$count videos"

        if (count == 0) {
            binding.tvEmptyPlaylistNotice.visibility = View.VISIBLE
            binding.rvPlaylist.visibility = View.GONE
        } else {
            binding.tvEmptyPlaylistNotice.visibility = View.GONE
            binding.rvPlaylist.visibility = View.VISIBLE
        }

        StreamService.activePlaylist = playlist.toList()
    }

    private fun requestStartStream() {
        if (playlist.isEmpty()) {
            Toast.makeText(this, "Please select at least one MP4 video first.", Toast.LENGTH_SHORT).show()
            return
        }

        val url = binding.etStreamUrl.text.toString().trim()
        val key = binding.etStreamKey.text.toString().trim()

        if (url.isBlank()) {
            binding.tilStreamUrl.error = "Stream URL is required"
            return
        } else {
            binding.tilStreamUrl.error = null
        }

        if (key.isBlank()) {
            binding.tilStreamKey.error = "Stream Key is required"
            return
        } else {
            binding.tilStreamKey.error = null
        }

        preferences.saveServerUrl(url)
        preferences.saveStreamKey(key)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                return
            }
        }

        proceedStartStream()
    }

    private fun proceedStartStream() {
        StreamService.activePlaylist = playlist.toList()

        val intent = Intent(this, StreamService::class.java).apply {
            action = StreamService.ACTION_START_STREAM
        }
        ContextCompat.startForegroundService(this, intent)
    }

    private fun stopStream() {
        val intent = Intent(this, StreamService::class.java).apply {
            action = StreamService.ACTION_STOP_STREAM
        }
        startService(intent)
    }

    private fun observeStreamStatus() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                StreamService.streamStatus.collect { status ->
                    renderStatus(status)
                }
            }
        }
    }

    private fun renderStatus(status: StreamStatus) {
        binding.tvStatusTitle.text = status.state.name
        binding.tvHeaderStatusBadge.text = status.state.name

        playlistAdapter.setActiveIndex(status.currentIndex)

        when (status.state) {
            StreamState.IDLE -> {
                binding.ivStatusDot.setColorFilter(ContextCompat.getColor(this, R.color.text_muted))
                binding.tvStatusTitle.setTextColor(ContextCompat.getColor(this, R.color.text_primary))
                binding.tvStatusMessage.text = "Ready to configure and start streaming."
                binding.tvLiveTimer.visibility = View.GONE
                binding.tvBitrateInfo.visibility = View.GONE
                binding.btnStartLive.visibility = View.VISIBLE
                binding.btnStopLive.visibility = View.GONE
                enableInputs(true)
            }
            StreamState.PREPARING -> {
                binding.ivStatusDot.setColorFilter(ContextCompat.getColor(this, R.color.warning_amber))
                binding.tvStatusTitle.setTextColor(ContextCompat.getColor(this, R.color.warning_amber))
                binding.tvStatusMessage.text = "Preparing video encoder & audio tracks..."
                binding.tvLiveTimer.visibility = View.GONE
                binding.btnStartLive.visibility = View.GONE
                binding.btnStopLive.visibility = View.VISIBLE
                enableInputs(false)
            }
            StreamState.CONNECTING -> {
                binding.ivStatusDot.setColorFilter(ContextCompat.getColor(this, R.color.warning_amber))
                binding.tvStatusTitle.setTextColor(ContextCompat.getColor(this, R.color.warning_amber))
                binding.tvStatusMessage.text = "Connecting to YouTube Live ingest server..."
                binding.tvLiveTimer.visibility = View.GONE
                binding.btnStartLive.visibility = View.GONE
                binding.btnStopLive.visibility = View.VISIBLE
                enableInputs(false)
            }
            StreamState.LIVE -> {
                binding.ivStatusDot.setColorFilter(ContextCompat.getColor(this, R.color.live_green))
                binding.tvStatusTitle.setTextColor(ContextCompat.getColor(this, R.color.live_green))
                val videoText = status.currentVideoTitle ?: "Video"
                binding.tvStatusMessage.text = "Streaming: $videoText (#${status.currentIndex + 1} of ${status.totalVideos})"
                binding.tvLiveTimer.visibility = View.VISIBLE
                binding.tvLiveTimer.text = formatDuration(status.durationElapsedSeconds)

                if (status.bitrateBps > 0) {
                    binding.tvBitrateInfo.visibility = View.VISIBLE
                    binding.tvBitrateInfo.text = "Bitrate: ${status.bitrateBps / 1000} Kbps"
                }

                binding.btnStartLive.visibility = View.GONE
                binding.btnStopLive.visibility = View.VISIBLE
                enableInputs(false)
            }
            StreamState.RECONNECTING -> {
                binding.ivStatusDot.setColorFilter(ContextCompat.getColor(this, R.color.warning_amber))
                binding.tvStatusTitle.setTextColor(ContextCompat.getColor(this, R.color.warning_amber))
                binding.tvStatusMessage.text = status.errorMessage ?: "Attempting automatic reconnection..."
                binding.btnStartLive.visibility = View.GONE
                binding.btnStopLive.visibility = View.VISIBLE
                enableInputs(false)
            }
            StreamState.STOPPED -> {
                binding.ivStatusDot.setColorFilter(ContextCompat.getColor(this, R.color.text_muted))
                binding.tvStatusTitle.setTextColor(ContextCompat.getColor(this, R.color.text_secondary))
                binding.tvStatusMessage.text = status.errorMessage ?: "Stream stopped."
                binding.tvLiveTimer.visibility = View.GONE
                binding.tvBitrateInfo.visibility = View.GONE
                binding.btnStartLive.visibility = View.VISIBLE
                binding.btnStopLive.visibility = View.GONE
                enableInputs(true)
            }
            StreamState.ERROR -> {
                binding.ivStatusDot.setColorFilter(ContextCompat.getColor(this, R.color.error_red))
                binding.tvStatusTitle.setTextColor(ContextCompat.getColor(this, R.color.error_red))
                binding.tvStatusMessage.text = status.errorMessage ?: "Stream error occurred."
                binding.tvLiveTimer.visibility = View.GONE
                binding.tvBitrateInfo.visibility = View.GONE
                binding.btnStartLive.visibility = View.VISIBLE
                binding.btnStopLive.visibility = View.GONE
                enableInputs(true)
            }
        }
    }

    private fun enableInputs(enable: Boolean) {
        binding.btnSelectVideos.isEnabled = enable
        binding.etStreamUrl.isEnabled = enable
        binding.etStreamKey.isEnabled = enable
        binding.rb720p.isEnabled = enable
        binding.rb1080p.isEnabled = enable
        binding.switchLoopPlaylist.isEnabled = enable
    }

    private fun formatDuration(seconds: Long): String {
        val h = seconds / 3600
        val m = (seconds % 3600) / 60
        val s = seconds % 60
        return if (h > 0) {
            String.format("%02d:%02d:%02d", h, m, s)
        } else {
            String.format("%02d:%02d", m, s)
        }
    }
}
