package com.monir.youtubelivestreamer.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import com.monir.youtubelivestreamer.R
import com.monir.youtubelivestreamer.YouTubeStreamerApp
import com.monir.youtubelivestreamer.model.PlaylistItem
import com.monir.youtubelivestreamer.model.StreamQuality
import com.monir.youtubelivestreamer.model.StreamState
import com.monir.youtubelivestreamer.model.StreamStatus
import com.monir.youtubelivestreamer.security.SecureStreamPreferences
import com.monir.youtubelivestreamer.ui.MainActivity
import com.pedro.common.ConnectChecker
import com.pedro.encoder.input.decoder.AudioDecoderInterface
import com.pedro.encoder.input.decoder.VideoDecoderInterface
import com.pedro.library.rtmp.RtmpFromFile
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.IOException

class StreamService : Service(), ConnectChecker, VideoDecoderInterface, AudioDecoderInterface {

    companion object {
        private const val TAG = "StreamService"
        const val ACTION_START_STREAM = "com.monir.youtubelivestreamer.START_STREAM"
        const val ACTION_STOP_STREAM = "com.monir.youtubelivestreamer.STOP_STREAM"

        private val _streamStatus = MutableStateFlow(StreamStatus())
        val streamStatus: StateFlow<StreamStatus> = _streamStatus.asStateFlow()

        var activePlaylist: List<PlaylistItem> = emptyList()
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var timerJob: Job? = null
    private var reconnectJob: Job? = null

    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null

    private var rtmpFromFile: RtmpFromFile? = null
    private lateinit var preferences: SecureStreamPreferences

    private var currentVideoIndex = 0
    private var isLoopEnabled = false
    private var targetQuality: StreamQuality = StreamQuality.P720
    private var fullStreamEndpoint = ""

    private var isUserStopRequested = false
    private var reconnectAttempts = 0
    private val maxReconnectAttempts = 5
    private var liveStartTime = 0L

    override fun onCreate() {
        super.onCreate()
        preferences = SecureStreamPreferences(this)
        acquireLocks()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_STREAM -> {
                startForegroundStreaming()
            }
            ACTION_STOP_STREAM -> {
                stopStreamingManually()
            }
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun startForegroundStreaming() {
        isUserStopRequested = false
        reconnectAttempts = 0
        currentVideoIndex = 0

        val serverUrl = preferences.getServerUrl().trim()
        val streamKey = preferences.getStreamKey().trim()
        isLoopEnabled = preferences.isLoopPlaylist()
        targetQuality = preferences.getQuality()

        if (serverUrl.isBlank() || streamKey.isBlank()) {
            updateStatus(StreamState.ERROR, errorMessage = "Server URL or Stream Key is empty.")
            stopSelf()
            return
        }

        if (activePlaylist.isEmpty()) {
            updateStatus(StreamState.ERROR, errorMessage = "No videos in playlist to stream.")
            stopSelf()
            return
        }

        fullStreamEndpoint = if (serverUrl.endsWith("/")) {
            "$serverUrl$streamKey"
        } else {
            "$serverUrl/$streamKey"
        }

        val notification = buildNotification("Initializing YouTube stream...", StreamState.PREPARING)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                YouTubeStreamerApp.NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } else {
            startForeground(YouTubeStreamerApp.NOTIFICATION_ID, notification)
        }

        updateStatus(StreamState.PREPARING, currentVideoIndex = 0)
        prepareAndStreamVideoAt(0)
    }

    private fun prepareAndStreamVideoAt(index: Int) {
        if (index < 0 || index >= activePlaylist.size) {
            if (isLoopEnabled && activePlaylist.isNotEmpty()) {
                currentVideoIndex = 0
                prepareAndStreamVideoAt(0)
                return
            } else {
                updateStatus(StreamState.STOPPED, errorMessage = "Playlist finished.")
                stopStreamingCleanup()
                return
            }
        }

        currentVideoIndex = index
        val item = activePlaylist[index]
        updateStatus(StreamState.CONNECTING, currentVideoIndex = index)

        try {
            rtmpFromFile?.let {
                if (it.isStreaming) it.stopStream()
            }

            rtmpFromFile = RtmpFromFile(applicationContext, this, this, this)

            val videoPrepared = rtmpFromFile?.prepareVideo(
                applicationContext,
                item.uri,
                targetQuality.videoBitrateBps,
                0
            ) ?: false

            val audioPrepared = rtmpFromFile?.prepareAudio(
                applicationContext,
                item.uri,
                targetQuality.audioBitrateBps
            ) ?: false

            if (!videoPrepared && !audioPrepared) {
                updateStatus(
                    StreamState.ERROR,
                    errorMessage = "Failed to prepare video/audio tracks for: ${item.title}"
                )
                stopStreamingCleanup()
                return
            }

            Log.i(TAG, "Starting stream for video #${index + 1}: ${item.title}")
            rtmpFromFile?.startStream(fullStreamEndpoint)

        } catch (e: IOException) {
            Log.e(TAG, "IOException while preparing media file", e)
            updateStatus(
                StreamState.ERROR,
                errorMessage = "Cannot read video file: ${e.localizedMessage ?: \"I/O Error\"}"
            )
            stopStreamingCleanup()
        } catch (e: Exception) {
            Log.e(TAG, "Unexpected error starting stream", e)
            updateStatus(
                StreamState.ERROR,
                errorMessage = "Stream start error: ${e.localizedMessage ?: \"Unknown\"}"
            )
            stopStreamingCleanup()
        }
    }

    override fun onConnectionStarted(url: String) {
        Log.i(TAG, "Connecting to YouTube Live ingest server...")
        updateStatus(StreamState.CONNECTING, currentVideoIndex = currentVideoIndex)
    }

    override fun onConnectionSuccess() {
        Log.i(TAG, "Connected to YouTube Live! Streaming now.")
        reconnectAttempts = 0
        liveStartTime = System.currentTimeMillis()
        updateStatus(StreamState.LIVE, currentVideoIndex = currentVideoIndex)
        startTimerJob()
    }

    override fun onConnectionFailed(reason: String) {
        Log.w(TAG, "Connection failed: $reason")
        if (isUserStopRequested) return
        handleReconnection("Connection failed: $reason")
    }

    override fun onDisconnect() {
        Log.i(TAG, "Disconnected from ingest server")
        if (isUserStopRequested) return
        handleReconnection("Disconnected from server")
    }

    override fun onAuthError() {
        Log.e(TAG, "YouTube Live Authentication Error. Verify your Stream Key.")
        updateStatus(
            StreamState.ERROR,
            errorMessage = "YouTube rejected credentials. Please verify your Stream Key in YouTube Studio."
        )
        stopStreamingCleanup()
    }

    override fun onAuthSuccess() {
        Log.i(TAG, "YouTube Live Authentication successful.")
    }

    override fun onNewBitrate(bitrate: Long) {
        _streamStatus.value = _streamStatus.value.copy(bitrateBps = bitrate)
    }

    override fun onVideoDecoderFinished() {
        Log.i(TAG, "Finished playback of video #${currentVideoIndex + 1}")
        serviceScope.launch {
            delay(500)
            if (!isUserStopRequested) {
                val nextIndex = currentVideoIndex + 1
                prepareAndStreamVideoAt(nextIndex)
            }
        }
    }

    override fun onAudioDecoderFinished() {}

    private fun handleReconnection(cause: String) {
        if (reconnectAttempts < maxReconnectAttempts) {
            reconnectAttempts++
            val backoffMs = 2000L * reconnectAttempts
            Log.w(TAG, "Reconnecting attempt $reconnectAttempts/$maxReconnectAttempts in ${backoffMs}ms. Cause: $cause")
            updateStatus(
                StreamState.RECONNECTING,
                errorMessage = "Reconnecting ($reconnectAttempts/$maxReconnectAttempts)..."
            )

            reconnectJob?.cancel()
            reconnectJob = serviceScope.launch {
                delay(backoffMs)
                if (!isUserStopRequested) {
                    try {
                        rtmpFromFile?.startStream(fullStreamEndpoint)
                    } catch (e: Exception) {
                        Log.e(TAG, "Reconnection attempt threw exception", e)
                    }
                }
            }
        } else {
            Log.e(TAG, "Max reconnect attempts reached. Halting stream.")
            updateStatus(
                StreamState.ERROR,
                errorMessage = "Network lost. Max reconnection attempts ($maxReconnectAttempts) reached."
            )
            stopStreamingCleanup()
        }
    }

    private fun stopStreamingManually() {
        isUserStopRequested = true
        updateStatus(StreamState.STOPPED, errorMessage = "Streaming stopped by user.")
        stopStreamingCleanup()
    }

    private fun stopStreamingCleanup() {
        timerJob?.cancel()
        reconnectJob?.cancel()

        try {
            rtmpFromFile?.let {
                if (it.isStreaming) it.stopStream()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping rtmpFromFile", e)
        }
        rtmpFromFile = null

        releaseLocks()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun updateStatus(
        state: StreamState,
        currentVideoIndex: Int = this.currentVideoIndex,
        errorMessage: String? = null
    ) {
        val currentTitle = if (currentVideoIndex in activePlaylist.indices) {
            activePlaylist[currentVideoIndex].title
        } else null

        val elapsed = if (state == StreamState.LIVE && liveStartTime > 0L) {
            (System.currentTimeMillis() - liveStartTime) / 1000L
        } else 0L

        val status = StreamStatus(
            state = state,
            currentVideoTitle = currentTitle,
            currentIndex = currentVideoIndex,
            totalVideos = activePlaylist.size,
            durationElapsedSeconds = elapsed,
            bitrateBps = _streamStatus.value.bitrateBps,
            errorMessage = errorMessage
        )
        _streamStatus.value = status

        val notifMessage = when (state) {
            StreamState.LIVE -> "LIVE: ${currentTitle ?: \"Streaming\"} (${formatDuration(elapsed)})"
            StreamState.CONNECTING -> "Connecting to YouTube Live..."
            StreamState.PREPARING -> "Preparing video tracks..."
            StreamState.RECONNECTING -> "Reconnecting to network..."
            StreamState.STOPPED -> "Streaming stopped"
            StreamState.ERROR -> "Error: ${errorMessage ?: \"Unknown error\"}"
            StreamState.IDLE -> "Idle"
        }
        updateNotification(notifMessage, state)
    }

    private fun startTimerJob() {
        timerJob?.cancel()
        timerJob = serviceScope.launch {
            while (true) {
                delay(1000)
                if (_streamStatus.value.state == StreamState.LIVE && liveStartTime > 0L) {
                    val elapsed = (System.currentTimeMillis() - liveStartTime) / 1000L
                    _streamStatus.value = _streamStatus.value.copy(durationElapsedSeconds = elapsed)
                    val currentTitle = _streamStatus.value.currentVideoTitle ?: "Video"
                    updateNotification("LIVE: $currentTitle (${formatDuration(elapsed)})", StreamState.LIVE)
                }
            }
        }
    }

    private fun buildNotification(message: String, state: StreamState): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val contentPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, StreamService::class.java).apply {
            action = ACTION_STOP_STREAM
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(this, YouTubeStreamerApp.CHANNEL_ID)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(message)
            .setSmallIcon(R.drawable.ic_play)
            .setContentIntent(contentPendingIntent)
            .setOngoing(state == StreamState.LIVE || state == StreamState.CONNECTING)
            .setPriority(NotificationCompat.PRIORITY_LOW)

        if (state == StreamState.LIVE || state == StreamState.CONNECTING || state == StreamState.RECONNECTING) {
            builder.addAction(R.drawable.ic_stop, "STOP LIVE", stopPendingIntent)
        }

        return builder.build()
    }

    private fun updateNotification(message: String, state: StreamState) {
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
        notificationManager.notify(YouTubeStreamerApp.NOTIFICATION_ID, buildNotification(message, state))
    }

    private fun acquireLocks() {
        try {
            val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = powerManager.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "YouTubeLiveStreamer:StreamingWakeLock"
            ).apply {
                acquire(12 * 60 * 60 * 1000L)
            }

            val wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            wifiLock = wifiManager.createWifiLock(
                WifiManager.WIFI_MODE_FULL_HIGH_PERF,
                "YouTubeLiveStreamer:StreamingWifiLock"
            ).apply {
                acquire()
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to acquire wake/wifi locks", e)
        }
    }

    private fun releaseLocks() {
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
            wakeLock = null
            if (wifiLock?.isHeld == true) wifiLock?.release()
            wifiLock = null
        } catch (e: Exception) {
            Log.w(TAG, "Failed to release wake/wifi locks", e)
        }
    }

    private fun formatDuration(seconds: Long): String {
        val h = seconds / 3600
        val m = (seconds % 3600) / 60
        val s = seconds % 60
        return if (h > 0) {
            String.format("%02d:%02d:%02d", h, m, s)
        } else {
            String.format("%02d:%02d", m, s)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        releaseLocks()
    }
}
