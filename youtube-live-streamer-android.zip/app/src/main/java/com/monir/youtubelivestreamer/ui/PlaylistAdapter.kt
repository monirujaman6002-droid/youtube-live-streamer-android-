package com.monir.youtubelivestreamer.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.monir.youtubelivestreamer.R
import com.monir.youtubelivestreamer.model.PlaylistItem

class PlaylistAdapter(
    private val onRemoveClick: (PlaylistItem) -> Unit
) : ListAdapter<PlaylistItem, PlaylistAdapter.ViewHolder>(DiffCallback) {

    private var activePlayingIndex: Int = -1

    fun setActiveIndex(index: Int) {
        if (activePlayingIndex != index) {
            val oldIndex = activePlayingIndex
            activePlayingIndex = index
            if (oldIndex in 0 until itemCount) notifyItemChanged(oldIndex)
            if (activePlayingIndex in 0 until itemCount) notifyItemChanged(activePlayingIndex)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_playlist_video, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = getItem(position)
        holder.bind(item, position, position == activePlayingIndex)
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvIndexBadge: TextView = itemView.findViewById(R.id.tvIndexBadge)
        private val tvVideoTitle: TextView = itemView.findViewById(R.id.tvVideoTitle)
        private val tvVideoMeta: TextView = itemView.findViewById(R.id.tvVideoMeta)
        private val ivNowPlayingIndicator: ImageView = itemView.findViewById(R.id.ivNowPlayingIndicator)
        private val btnRemoveVideo: ImageButton = itemView.findViewById(R.id.btnRemoveVideo)

        fun bind(item: PlaylistItem, position: Int, isPlaying: Boolean) {
            tvIndexBadge.text = "#${position + 1}"
            tvVideoTitle.text = item.title

            val sizeMb = String.format("%.1f MB", item.sizeBytes / (1024.0 * 1024.0))
            val durationText = formatDuration(item.durationMs)
            tvVideoMeta.text = "$durationText • $sizeMb"

            ivNowPlayingIndicator.visibility = if (isPlaying) View.VISIBLE else View.GONE
            btnRemoveVideo.setOnClickListener {
                onRemoveClick(item)
            }
        }

        private fun formatDuration(durationMs: Long): String {
            if (durationMs <= 0) return "00:00"
            val totalSeconds = durationMs / 1000
            val minutes = totalSeconds / 60
            val seconds = totalSeconds % 60
            val hours = minutes / 60
            return if (hours > 0) {
                String.format("%02d:%02d:%02d", hours, minutes % 60, seconds)
            } else {
                String.format("%02d:%02d", minutes, seconds)
            }
        }
    }

    companion object {
        private val DiffCallback = object : DiffUtil.ItemCallback<PlaylistItem>() {
            override fun areItemsTheSame(oldItem: PlaylistItem, newItem: PlaylistItem): Boolean {
                return oldItem.id == newItem.id
            }

            override fun areContentsTheSame(oldItem: PlaylistItem, newItem: PlaylistItem): Boolean {
                return oldItem == newItem
            }
        }
    }
}
