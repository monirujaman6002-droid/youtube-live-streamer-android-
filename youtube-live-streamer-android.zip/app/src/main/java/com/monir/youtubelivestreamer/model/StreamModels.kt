package com.monir.youtubelivestreamer.model

import android.net.Uri

enum class StreamState {
    IDLE,
    PREPARING,
    CONNECTING,
    LIVE,
    RECONNECTING,
    STOPPED,
    ERROR
}

enum class StreamQuality(
    val label: String,
    val width: Int,
    val height: Int,
    val videoBitrateBps: Int,
    val audioBitrateBps: Int,
    val fps: Int
) {
    P720("720p (HD)", 1280, 720, 2_500_000, 128_000, 30),
    P1080("1080p (FHD)", 1920, 1080, 4_500_000, 128_000, 30);

    companion object {
        fun fromKey(key: String): StreamQuality {
            return if (key.equals("1080p", ignoreCase = true)) P1080 else P720
        }
    }
}

data class PlaylistItem(
    val id: String,
    val uri: Uri,
    val title: String,
    val sizeBytes: Long,
    val durationMs: Long
)

data class StreamStatus(
    val state: StreamState = StreamState.IDLE,
    val currentVideoTitle: String? = null,
    val currentIndex: Int = -1,
    val totalVideos: Int = 0,
    val durationElapsedSeconds: Long = 0L,
    val bitrateBps: Long = 0L,
    val errorMessage: String? = null
)
