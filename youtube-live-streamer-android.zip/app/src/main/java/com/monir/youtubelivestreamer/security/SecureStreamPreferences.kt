package com.monir.youtubelivestreamer.security

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.monir.youtubelivestreamer.model.StreamQuality

class SecureStreamPreferences(context: Context) {

    private val sharedPreferences: SharedPreferences

    companion object {
        private const val TAG = "SecureStreamPrefs"
        private const val PREFS_FILE_NAME = "secure_youtube_stream_config"
        private const val KEY_SERVER_URL = "secure_server_url"
        private const val KEY_STREAM_KEY = "secure_stream_key"
        private const val KEY_STREAM_QUALITY = "secure_stream_quality"
        private const val KEY_LOOP_PLAYLIST = "secure_loop_playlist"
        const val DEFAULT_SERVER_URL = "rtmps://a.rtmps.youtube.com/live2"
    }

    init {
        sharedPreferences = try {
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()

            EncryptedSharedPreferences.create(
                context,
                PREFS_FILE_NAME,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error initializing hardware-backed EncryptedSharedPreferences, falling back to private prefs", e)
            context.getSharedPreferences(PREFS_FILE_NAME, Context.MODE_PRIVATE)
        }
    }

    fun saveServerUrl(url: String) {
        sharedPreferences.edit().putString(KEY_SERVER_URL, url.trim()).apply()
    }

    fun getServerUrl(): String {
        return sharedPreferences.getString(KEY_SERVER_URL, DEFAULT_SERVER_URL) ?: DEFAULT_SERVER_URL
    }

    fun saveStreamKey(key: String) {
        sharedPreferences.edit().putString(KEY_STREAM_KEY, key.trim()).apply()
    }

    fun getStreamKey(): String {
        return sharedPreferences.getString(KEY_STREAM_KEY, "") ?: ""
    }

    fun hasStreamKey(): Boolean {
        return getStreamKey().isNotBlank()
    }

    fun saveQuality(quality: StreamQuality) {
        sharedPreferences.edit().putString(KEY_STREAM_QUALITY, quality.name).apply()
    }

    fun getQuality(): StreamQuality {
        val name = sharedPreferences.getString(KEY_STREAM_QUALITY, StreamQuality.P720.name)
        return try {
            StreamQuality.valueOf(name ?: StreamQuality.P720.name)
        } catch (e: Exception) {
            StreamQuality.P720
        }
    }

    fun saveLoopPlaylist(enabled: Boolean) {
        sharedPreferences.edit().putBoolean(KEY_LOOP_PLAYLIST, enabled).apply()
    }

    fun isLoopPlaylist(): Boolean {
        return sharedPreferences.getBoolean(KEY_LOOP_PLAYLIST, false)
    }

    fun clearCredentials() {
        sharedPreferences.edit()
            .remove(KEY_STREAM_KEY)
            .apply()
    }
}
