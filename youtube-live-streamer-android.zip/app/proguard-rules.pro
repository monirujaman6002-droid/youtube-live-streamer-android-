# Keep RootEncoder and Pedro streaming classes
-keep class com.pedro.** { *; }
-keep interface com.pedro.** { *; }

# Keep AndroidX Security Crypto and Tink classes
-keep class androidx.security.crypto.** { *; }
-keep class com.google.crypto.tink.** { *; }
