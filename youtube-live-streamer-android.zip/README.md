# YouTube Live Streamer (Android)

An Android application designed to stream pre-recorded local MP4 videos directly from your Android phone's storage to **YouTube Live** via RTMP / RTMPS with hardware video encoding and high-fidelity audio pass-through.

Built for Android 16, 15, 14, and earlier, requiring **no Android Studio or computer**—fully configured for automated APK compilation in GitHub Actions.
